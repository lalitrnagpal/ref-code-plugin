package com.vp.plugin.sample.reloadclasses;

import com.vp.plugin.*;

public class ReloadClassesPlugin implements VPPlugin {

	@Override
	public void loaded(VPPluginInfo aPluginInfo) {
	}

	@Override
	public void unloaded() {
	}

}
