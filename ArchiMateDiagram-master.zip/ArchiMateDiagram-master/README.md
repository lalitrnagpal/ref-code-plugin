This open source plugin support create ArchiMate in Visual Paradigm.

Details about how to deploy this plugin to Visual Paradigm can be found at https://knowhow.visual-paradigm.com/openapi/how-to-deploy-plugins-to-vp-application/

More details about this plugin can be found at https://knowhow.visual-paradigm.com/openapi/archimate-diagram/
