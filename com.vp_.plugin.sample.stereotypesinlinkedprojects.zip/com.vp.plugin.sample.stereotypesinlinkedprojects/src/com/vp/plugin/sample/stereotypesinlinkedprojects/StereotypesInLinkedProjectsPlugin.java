package com.vp.plugin.sample.stereotypesinlinkedprojects;

import com.vp.plugin.*;

public class StereotypesInLinkedProjectsPlugin implements VPPlugin {
	
	public void loaded(VPPluginInfo aArg0) {
	}
	public void unloaded() {
	}
	
}