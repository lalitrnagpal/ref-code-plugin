package com.vp.plugin.sample.stereotypesinlinkedprojects.actions;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

import com.vp.plugin.*;
import com.vp.plugin.action.*;
import com.vp.plugin.model.*;
import com.vp.plugin.model.factory.*;

public class AddStereotypeFromLinkedProjectsActionController implements VPContextActionController {

	public void performAction(VPAction aAction, VPContext aContext, ActionEvent aE) {
		
		IClass lModelElement = (IClass) aContext.getModelElement();
		
		StereotypeAndProject[] lStereotypes = collectStereotypes(lModelElement);
		int lCount = lStereotypes == null ? 0 : lStereotypes.length;
		if (lCount > 0) {
			DefaultListModel lListModel = new DefaultListModel(); // <StereotypeAndProject>
			for (int i = 0; i < lCount; i++) {
				lListModel.addElement(lStereotypes[i]);
			}
			JList lList = new JList(lListModel);
			lList.setCellRenderer(new DefaultListCellRenderer() {
				public Component getListCellRendererComponent(JList aList, Object aValue, int aIndex, boolean aIsSelected, boolean aCellHasFocus) {
					Component lComponent = super.getListCellRendererComponent(aList, aValue, aIndex, aIsSelected, aCellHasFocus);
					if (aValue instanceof StereotypeAndProject) {
						if (((StereotypeAndProject) aValue).addedAlready) {
							lComponent.setForeground(Color.blue); // added already
						}
					}
					return lComponent;
				}
			});
			
			JLabel lLabel = new JLabel("Select a stereotype:");
			JPanel lPanel = new JPanel(new BorderLayout());
			lPanel.add(lLabel, BorderLayout.NORTH);
			lPanel.add(new JScrollPane(lList), BorderLayout.CENTER);
			lPanel.setPreferredSize(new Dimension(400, 300));
			
			int lResult = ApplicationManager.instance().getViewManager().showConfirmDialog(null, lPanel, "Add Stereotype", JOptionPane.OK_CANCEL_OPTION);
			if (lResult == JOptionPane.OK_OPTION) {
				StereotypeAndProject lValue = (StereotypeAndProject) lList.getSelectedValue();
				if (lValue != null) {
					if (! lValue.addedAlready) {
						lModelElement.addStereotype(lValue.stereotype);
					}
				}
				else {
					ApplicationManager.instance().getViewManager().showMessageDialog(null, "No stereotype is selected to be added.", "Error", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			
			
		}
		else {
			ApplicationManager.instance().getViewManager().showMessageDialog(null, "No stereotype found for: " + lModelElement.getModelType(), "Not Found", JOptionPane.WARNING_MESSAGE);
		}
		
		
		
	}

	public void update(VPAction aAction, VPContext aContext) {
	}
	
	private StereotypeAndProject[] collectStereotypes(IClass aModelElement) {
		String lBaseType = aModelElement.getModelType();
		
		Collection lCollection = new ArrayList(); // <StereotypeAndProject>
		
		Collection lInUses = new ArrayList(); // <IStereotype>
		{
			IStereotype[] lStereotypes = aModelElement.toStereotypeModelArray();
			int lCount = lStereotypes == null ? 0 : lStereotypes.length;
			for (int i = 0; i < lCount; i++) {
				lInUses.add(lStereotypes[i]);
			}
		}
		
		IProject lProject = ApplicationManager.instance().getProjectManager().getProject();
		collect(lProject, lBaseType, lCollection, lInUses);
		
		StereotypeAndProject[] lStereotypes = new StereotypeAndProject[lCollection.size()];
		lCollection.toArray(lStereotypes);
		return lStereotypes;
	}
	private void collect(IProject aProject, String aBaseType, Collection aCollection, Collection aInUses) {
		{
			// stereotypes
			IModelElement[] lStereotypes = aProject.toAllLevelModelElementArray(IModelElementFactory.MODEL_TYPE_STEREOTYPE);
			int lCount = lStereotypes == null ? 0 : lStereotypes.length;
			for (int i = 0; i < lCount; i++) {
				IStereotype lStereotype = (IStereotype) lStereotypes[i];
				if (aBaseType.equals(lStereotype.getBaseType())) {
					aCollection.add(new StereotypeAndProject(lStereotype, aProject.getName(), aInUses.contains(lStereotype)));
				}
			}
		}
		
		{
			// linked projects
			IProject[] lLinkedProjects = aProject.getLinkedProjects();
			int lCount = lLinkedProjects == null ? 0 : lLinkedProjects.length;
			for (int i = 0; i < lCount; i++) {
				collect(lLinkedProjects[i], aBaseType, aCollection, aInUses);
			}
		}
		
	}
	
	private static class StereotypeAndProject {
		public final IStereotype stereotype;
		public final String projectName;
		public final boolean addedAlready;
		
		public StereotypeAndProject(IStereotype aStereotype, String aProjectName, boolean aAddedAlready) {
			this.stereotype = aStereotype;
			this.projectName = aProjectName;
			this.addedAlready = aAddedAlready;
		}
		
		public String toString() { 
			return this.stereotype.getName() + " ("+this.projectName+")";
		}
	}

}