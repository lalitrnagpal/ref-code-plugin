package com.vp.plugin.sample.layer.actions;

import com.vp.plugin.ApplicationManager;
import com.vp.plugin.action.VPAction;
import com.vp.plugin.action.VPActionController;
import com.vp.plugin.diagram.IConnectorUIModel;
import com.vp.plugin.diagram.IDiagramElement;
import com.vp.plugin.diagram.IDiagramLayer;
import com.vp.plugin.diagram.IDiagramUIModel;
import com.vp.plugin.model.IConnector;

public class LayerActionControl implements VPActionController {

	@Override
	public void performAction(VPAction arg0) {
		// retrieve the current opening diagram
		IDiagramUIModel diagram = ApplicationManager.instance().getDiagramManager().getActiveDiagram();
		
		// create 2 diagram layers
		IDiagramLayer shapeLayer = diagram.createDiagramLayer("Shapes");
		IDiagramLayer connectorLayer = diagram.createDiagramLayer("Connectors");
		
		// retrieve all diagram elements on the diagram
		IDiagramElement[] elements = diagram.toDiagramElementArray();
		
		if (elements != null) {
			for (int i = 0; i < elements.length; i++) {
				IDiagramElement element = elements[i];
				if (element instanceof IConnectorUIModel) {
					// add to connector layer 
					connectorLayer.addDiagramElement(element);					
				} else {
					// add the shape layer
					shapeLayer.addDiagramElement(element);
				}				
			}
		}
		ApplicationManager.instance().getViewManager().showMessage("Finish create diagram layer");
	}

	@Override
	public void update(VPAction arg0) {
		// TODO Auto-generated method stub
		
	}

}
