This open source plugin support automatically generate document from Business Process Diagram with Doc. Composer using user specified XML template.

Details about how to deploy this plugin to Visual Paradigm can be found at https://knowhow.visual-paradigm.com/openapi/how-to-deploy-plugins-to-vp-application/

More details about this plugin can be found at https://knowhow.visual-paradigm.com/openapi/doc-composer-open-api/

* Please note that this plugin only works for VP Client version 15.0 build 20180415fi (or later) release. 
