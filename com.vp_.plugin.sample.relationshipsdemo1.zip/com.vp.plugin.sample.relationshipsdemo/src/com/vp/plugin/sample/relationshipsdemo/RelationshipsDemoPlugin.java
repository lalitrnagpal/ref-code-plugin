package com.vp.plugin.sample.relationshipsdemo;

import com.vp.plugin.*;

public class RelationshipsDemoPlugin implements VPPlugin {

	public void loaded(VPPluginInfo aArg0) {
	}

	public void unloaded() {
	}

}
