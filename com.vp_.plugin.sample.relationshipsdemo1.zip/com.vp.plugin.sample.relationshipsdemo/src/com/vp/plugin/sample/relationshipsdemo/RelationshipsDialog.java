package com.vp.plugin.sample.relationshipsdemo;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.table.*;

import com.vp.plugin.*;
import com.vp.plugin.diagram.*;
import com.vp.plugin.model.*;
import com.vp.plugin.view.*;

public class RelationshipsDialog implements IDialogHandler {
	
	private final IModelElement _model;
	private final Component _component;
	private IDialog _dialog;
	
	public RelationshipsDialog(IModelElement aModel) {
		_model = aModel;
		
		RelationshipTableModelImpl lSimpleRelationshipTableModel;
		{
			Collection lCollection = new ArrayList(); // <IRelationship>
			{
				// from base TO opposite
				Iterator lIter = aModel.fromRelationshipIterator();
				while (lIter.hasNext()) {
					IRelationship lRelationship = (IRelationship) lIter.next();
					lCollection.add(lRelationship);
				}
			}
			{
				// FROM opposite to base
				Iterator lIter = aModel.toRelationshipIterator();
				while (lIter.hasNext()) {
					IRelationship lRelationship = (IRelationship) lIter.next();
					if (aModel.equals(lRelationship.getFrom())) {
						// ignore, it is SELF, already included in "from base to opposite"
					}
					else {
						lCollection.add(lRelationship);
					}
				}
			}
			
			IRelationship[] lRelationships = new IRelationship[lCollection.size()];
			lCollection.toArray(lRelationships);
			lSimpleRelationshipTableModel = new RelationshipTableModelImpl(aModel, lRelationships);
		}
		
		RelationshipTableModelImpl lEndRelationshipTableModel;
		{
			Collection lCollection = new ArrayList(); // <IRelationship>
			{
				// from base TO opposite
				Iterator lIter = aModel.fromRelationshipEndIterator();
				while (lIter.hasNext()) {
					IRelationshipEnd lRelationshipEnd = (IRelationshipEnd) lIter.next();
					IRelationship lRelationship = lRelationshipEnd.getEndRelationship();
					lCollection.add(lRelationship);
				}
			}
			{
				// FROM opposite to base
				Iterator lIter = aModel.toRelationshipEndIterator();
				while (lIter.hasNext()) {
					IRelationshipEnd lRelationshipEnd = (IRelationshipEnd) lIter.next();
					IRelationship lRelationship = lRelationshipEnd.getEndRelationship();
					if (aModel.equals(lRelationship.getFrom())) {
						// ignore, it is SELF, already included in "from base to opposite"
					}
					else {
						lCollection.add(lRelationship);
					}
				}
			}
			
			IRelationship[] lRelationships = new IRelationship[lCollection.size()];
			lCollection.toArray(lRelationships);
			lEndRelationshipTableModel = new RelationshipTableModelImpl(aModel, lRelationships);
		}
		
		JLabel lSimpleRelationshipLabel = new JLabel("Simple Relationships:");
		JTable lSimpleRelationshipTable = new JTable(lSimpleRelationshipTableModel);
		JScrollPane lSimpleRelationshipScrollPane = new JScrollPane(lSimpleRelationshipTable);
		JTable lEndRelationshipTable = new JTable(lEndRelationshipTableModel);
		JScrollPane lEndRelationshipScrollPane = new JScrollPane(lEndRelationshipTable);
		
		JLabel lEndRelationshipLabel = new JLabel("End Relationships:");
		lSimpleRelationshipTable.getColumnModel().getColumn(RelationshipTableModelImpl.Columns.RelationshipType).setCellRenderer(new ModelTypeCellRenderer());
		lSimpleRelationshipTable.getColumnModel().getColumn(RelationshipTableModelImpl.Columns.Model).setCellRenderer(new ModelElementCellRenderer());
		lEndRelationshipTable.getColumnModel().getColumn(RelationshipTableModelImpl.Columns.RelationshipType).setCellRenderer(new ModelTypeCellRenderer());
		lEndRelationshipTable.getColumnModel().getColumn(RelationshipTableModelImpl.Columns.Model).setCellRenderer(new ModelElementCellRenderer());
		
		JButton lCloseButton = new JButton("Close");
		
		JPanel lPanel = new JPanel();
		{
			GridBagLayout lLayout = new GridBagLayout();
			lPanel.setLayout(lLayout);
			
			GridBagConstraints lCons = new GridBagConstraints();
			lCons.anchor = GridBagConstraints.CENTER;
			lCons.gridwidth = GridBagConstraints.REMAINDER;
			lLayout.setConstraints(lCloseButton, lCons);
			
			lCons.anchor = GridBagConstraints.WEST;
			lLayout.setConstraints(lSimpleRelationshipLabel, lCons);
			lLayout.setConstraints(lEndRelationshipLabel, lCons);
			
			lCons.weightx = 1;
			lCons.weighty =1 ;
			lCons.fill = GridBagConstraints.BOTH;
			lCons.insets.bottom = 10;
			lLayout.setConstraints(lSimpleRelationshipScrollPane, lCons);
			lLayout.setConstraints(lEndRelationshipScrollPane, lCons);
		}
		lPanel.add(lSimpleRelationshipLabel);
		lPanel.add(lSimpleRelationshipScrollPane);
		lPanel.add(lEndRelationshipLabel);
		lPanel.add(lEndRelationshipScrollPane);
		lPanel.add(lCloseButton);
		
		_component = lPanel;
		
		
		lCloseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent aE) {
				_dialog.close();
			}
		});
		MouseListener lSelectModelElementMouseListener = new MouseListener() {
			public void mouseClicked(MouseEvent aE) {
				if (aE.getClickCount() > 1) {
					JTable lTable = (JTable) aE.getComponent();
					
					Point lLocation = aE.getPoint();
					
					IModelElement lModelElement = null;
					
					int lRow = lTable.rowAtPoint(lLocation);
					int lColumn = lTable.columnAtPoint(lLocation);
					if (lColumn == RelationshipTableModelImpl.Columns.Model) {
						lModelElement = (IModelElement) lTable.getValueAt(lRow, lColumn);
					}
					else {
						lModelElement = ((RelationshipTableModelImpl) lTable.getModel()).getRelationship(lRow);
					}
					
					if (lModelElement != null) {
						IDiagramElement lDiagramElement = lModelElement.getMasterView();
						if (lDiagramElement == null) {
							IDiagramElement[] lDiagramElements = lModelElement.getDiagramElements();
							if (lDiagramElements != null && lDiagramElements.length > 0) {
								lDiagramElement = lDiagramElements[0];
							}
						}
						if (lDiagramElement != null) {
							ApplicationManager.instance().getDiagramManager().highlight(lDiagramElement);
						}
					}
					
				}
				
			}
			public void mouseEntered(MouseEvent aE) {}
			public void mouseExited(MouseEvent aE) {}
			public void mousePressed(MouseEvent aE) {}
			public void mouseReleased(MouseEvent aE) {}
		};
		lSimpleRelationshipTable.addMouseListener(lSelectModelElementMouseListener);
		lEndRelationshipTable.addMouseListener(lSelectModelElementMouseListener);
		
	}

	public boolean canClosed() {
		return true;
	}

	public Component getComponent() {
		return _component;
	}

	public void prepare(IDialog aDialog) {
		_dialog = aDialog;
		
		aDialog.setSize(500, 450);
		aDialog.setTitle("Show Relationships - DEMO");
		aDialog.setModal(false);
	}

	public void shown() {
	}
	
	private static class RelationshipTableModelImpl extends AbstractTableModel {
		
		private final IModelElement _base;
		private final IRelationship[] _relationships;
		
		public RelationshipTableModelImpl(IModelElement aBase, IRelationship[] aRelationships) {
			_base = aBase;
			_relationships = aRelationships;
		}
		
		public static class Columns {
			public static final int
				RelationshipType = 0, // ModelType of Relationship
				RelationshipName = 1, // Name of Relationship
				Direction = 2, // From/To/Self
				Model = 3; // Opposite Model of the Relationship
		}
		
		public IRelationship getRelationship(int aRowIndex) {
			return _relationships[aRowIndex];
		}
		
		public int getColumnCount() {
			return 4;
		}
		
		public Class getColumnClass(int aColumnIndex) {
			switch (aColumnIndex) {
				case Columns.RelationshipType: 
					return String.class;
				case Columns.RelationshipName: 
					return String.class;
				case Columns.Direction: 
					return String.class;
				case Columns.Model: 
					return IModelElement.class;
			}
			return null;
		}

		public String getColumnName(int aColumnIndex) {
			switch (aColumnIndex) {
				case Columns.RelationshipType: 
					return "Type";
				case Columns.RelationshipName: 
					return "Name";
				case Columns.Direction:
					return "Direction";
				case Columns.Model:
					return "Model Element";
			}
			return null;
		}

		public int getRowCount() {
			return _relationships.length;
		}
		
		public Object getValueAt(int aRowIndex, int aColumnIndex) {
			IRelationship lRelationship = _relationships[aRowIndex];
			switch (aColumnIndex) {
				case Columns.RelationshipType: 
					return lRelationship.getModelType();
				case Columns.RelationshipName: {
					String lName = lRelationship.getNickname();
					return (lName == null || lName.length() == 0) ? "Unnamed" : lName;
				}
				case Columns.Direction:
					if (_base.equals(lRelationship.getFrom())) {
						if (_base.equals(lRelationship.getTo())) {
							return "Self";
						}
						else {
							return "To"; // from base TO opposite model
						}
					}
					else {
						return "From"; // FROM opposite model to base
					}
				case Columns.Model:
					if (_base.equals(lRelationship.getTo())) {
						return lRelationship.getFrom();
					}
					else {
						return lRelationship.getTo();
					}
			}
			return null;
		}

		public boolean isCellEditable(int aRowIndex, int aColumnIndex) {
			return false;
		}
		public void setValueAt(Object aValue, int aRowIndex, int aColumnIndex) {
		}
		
	}
	
	private static class ModelTypeCellRenderer extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable aTable, Object aValue, boolean aIsSelected, boolean aHasFocus, int aRow, int aColumn) {
			Component lComponent = super.getTableCellRendererComponent(aTable, aValue, aIsSelected, aHasFocus, aRow, aColumn);
			
			if (lComponent instanceof JLabel && aValue instanceof String) {
				JLabel lLabel = (JLabel) lComponent;
				String lModelType = (String) aValue;
				
				ViewManager lViewManager = ApplicationManager.instance().getViewManager();
				String lName = lViewManager.getDisplayModelType(lModelType);
				Icon lIcon = lViewManager.getIconByModelType(lModelType);
				
				lLabel.setText(lName);
				lLabel.setIcon(lIcon);
			}
			
			return lComponent;
		}
	}
	private static class ModelElementCellRenderer extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable aTable, Object aValue, boolean aIsSelected, boolean aHasFocus, int aRow, int aColumn) {
			Component lComponent = super.getTableCellRendererComponent(aTable, aValue, aIsSelected, aHasFocus, aRow, aColumn);
			
			if (lComponent instanceof JLabel && aValue instanceof IModelElement) {
				JLabel lLabel = (JLabel) lComponent;
				IModelElement lModelElement = (IModelElement) aValue;
				
				ViewManager lViewManager = ApplicationManager.instance().getViewManager();
				String lName = lModelElement.getNickname();
				Icon lIcon = lViewManager.getIconByModelType(lModelElement.getModelType());
				
				lLabel.setText(lName);
				lLabel.setIcon(lIcon);
			}
			
			return lComponent;
		}
	}

}
