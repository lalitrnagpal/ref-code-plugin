package com.vp.plugin.sample.relationshipsdemo.actions;

import java.awt.event.*;

import javax.swing.*;

import com.vp.plugin.*;
import com.vp.plugin.action.*;
import com.vp.plugin.model.*;
import com.vp.plugin.sample.relationshipsdemo.*;

public class ShowRelationshipsActionController implements VPContextActionController {

	public void performAction(VPAction aAction, VPContext aContext, ActionEvent aE) {
		IModelElement lModelElement = aContext.getModelElement();
		if (
				lModelElement.fromRelationshipCount() > 0 || 
				lModelElement.fromRelationshipEndCount() > 0 || 
				lModelElement.toRelationshipCount() > 0 || 
				lModelElement.toRelationshipEndCount() > 0
		) {
			ApplicationManager.instance().getViewManager().showDialog(new RelationshipsDialog(lModelElement));
			
		}
		else {
			// no relationships
			ApplicationManager.instance().getViewManager().showMessageDialog(
					null, "No relationship connecting with this model element.", "Relationship Not Found", JOptionPane.INFORMATION_MESSAGE
			);
		}
		
	}

	public void update(VPAction aAction, VPContext aContext) {
		if (aContext.getModelElement() == null) {
			aAction.setEnabled(false);
		}
		else {
			aAction.setEnabled(true);
		}
	}

}
