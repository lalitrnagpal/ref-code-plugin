package com.vp.plugin.sample.generatereportcomposer.actions;

import java.util.*;

import com.vp.plugin.*;
import com.vp.plugin.action.*;
import com.vp.plugin.diagram.*;
import com.vp.plugin.model.*;
import com.vp.plugin.model.factory.*;

public class GenerateUseCaseDiagramsReportActionController implements VPActionController {

	@Override
	public void performAction(VPAction aAction) {
		
		IUseCaseDiagramUIModel[] lUseCaseDiagrams;
		{
			Collection<IUseCaseDiagramUIModel> lCollection = new ArrayList<IUseCaseDiagramUIModel>();
			
			IProject lProject = ApplicationManager.instance().getProjectManager().getProject();
			IDiagramUIModel[] lDiagrams = lProject.toDiagramArray();
			if (lDiagrams != null) {
				
				for (IDiagramUIModel lDiagram : lDiagrams) {
					if (lDiagram instanceof IUseCaseDiagramUIModel) {
						lCollection.add((IUseCaseDiagramUIModel) lDiagram);
					}
				}
			}
			
			lUseCaseDiagrams = lCollection.toArray(new IUseCaseDiagramUIModel[lCollection.size()]);
		}
		
		if (lUseCaseDiagrams != null && lUseCaseDiagrams.length > 0) {
			
			DiagramManager lDiagramManager = ApplicationManager.instance().getDiagramManager();
			IReportDiagramUIModel lReportDiagram = (IReportDiagramUIModel) lDiagramManager.createDiagram(IDiagramTypeConstants.DIAGRAM_TYPE_REPORT_DIAGRAM);
			
			IReportDiagramDetails lReportDiagramDetails;
			{
				// all ReportDiagramDetails should be contained in a ReportDiagramDetailsContainer. (one project have one ReportDiagramDetailsContainer only)
				IReportDiagramDetailsContainer lContainer;
				IProject lProject = ApplicationManager.instance().getProjectManager().getProject();
				Iterator lIter = lProject.modelElementIterator(IModelElementFactory.MODEL_TYPE_REPORT_DIAGRAM_DETAILS_CONTAINER);
				if (lIter.hasNext()) {
					lContainer = (IReportDiagramDetailsContainer) lIter.next();
				}
				else {
					lContainer = IModelElementFactory.instance().createReportDiagramDetailsContainer();
				}
				
				lReportDiagramDetails = lContainer.createReportDiagramDetails();
			}
			lReportDiagram.setGenericXMLElementAddress(lReportDiagramDetails.getAddress());
			
			for (IUseCaseDiagramUIModel lUseCaseDiagram : lUseCaseDiagrams) {
				
				{
					// UseCaseDiagram
					IRDOOTemplate lTemplate = lReportDiagramDetails.createRDOOTemplate();
//					lTemplate.setXmlFilePath("UseCaseDiagram/DiagramImage.xml");
					lTemplate.setTemplateURI("Diagram:UseCaseDiagram/Basic");
					lTemplate.setSourceType(1); // 1 for Diagram, 2 for DiagramElement, 3 for ModelElement
					lTemplate.setSourceId(lUseCaseDiagram.getId());
					
					lReportDiagramDetails.addTemplate(lTemplate);
				}
				
				IDiagramElement[] lUseCases = lUseCaseDiagram.toDiagramElementArray(IUseCaseDiagramUIModel.SHAPETYPE_USE_CASE);
				if (lUseCases != null) {
					for (IDiagramElement lUseCase : lUseCases) {
						// UseCase
						{
							// UseCase.BasicInformation
							IRDOOTemplate lTemplate = lReportDiagramDetails.createRDOOTemplate();
//							lTemplate.setXmlFilePath("UseCase/BasicInformation.xml");
							lTemplate.setTemplateURI("Element:UseCase/Details");
							lTemplate.setSourceType(3); // 1 for Diagram, 2 for DiagramElement, 3 for ModelElement
							lTemplate.setSourceId(lUseCase.getModelElement().getAddress());
							
							lReportDiagramDetails.addTemplate(lTemplate);
						}
					}
				}
				
				{
					// setting
					ReportManager lReportManager = ApplicationManager.instance().getReportManager();
					
					{
						// numbering
						IRDNumberingSetting lNumberingSetting = lReportDiagramDetails.createRDNumberingSetting();
						lReportManager.initDefaultRDNumberingSetting(lNumberingSetting);
					}
				}
			}
			
			
			
			lDiagramManager.openDiagram(lReportDiagram);
			
		}
	
	}

	@Override
	public void update(VPAction aAction) {
	}

}